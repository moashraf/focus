<?php
return[
    'app_id'=>'dc2be401-dd27-47c7-bfc3-e2948a68b771',
    'token'=>'0473383fc3caf8c471eb9799f0e8f020778f0502b2f417ea96216ea9d0ac8fa93b1205dbbdccdb6ec1f90be6b54beb057447e2894b2b0680c86f78ea658eb8e7'
];
